"""
Constants used across the ORM in general.
"""

# Separator used to split filter strings apart.
LOOKUP_SEP = '__'
